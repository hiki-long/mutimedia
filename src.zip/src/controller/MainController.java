package controller;
import javafx.fxml.FXML;

public class MainController {
	// TODO Auto-generated constructor stub
	public MainController()
	{
		
	}
	
	@FXML
	public void initialize()
	{
		System.out.println("ʵ��������");
	}
	
	
}
